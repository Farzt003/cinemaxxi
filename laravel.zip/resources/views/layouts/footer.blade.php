<footer class="app-footer text-white">
    <div>
        <a href="#">
            {{ config('app.name', 'StreamApp') }}
        </a>
        <span>
            © {{date("Y")}}.
        </span>
    </div>
    <div class="ml-auto">
        <span>
            Developed by
        </span>
        <a href="https://codecanyon.net/user/jennsenr">
            jennsen
        </a>
    </div>
</footer>