@extends('layouts.admin')

@section('content')
            <!-- Breadcrumb-->
            <ol class="breadcrumb">
                <li class="breadcrumb-item">Home</li>
            </ol>
            <div class="container-fluid">
                <dashboard-component></dashboard-component>
            </div>

@endsection
